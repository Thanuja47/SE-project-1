import React from 'react'
import { CCard, CCardBody, CCardHeader, CCol, CContainer, CRow } from '@coreui/react'

const FeeStructure = () => {
  return (
    <CContainer>
      <CRow>
        <CCol>
          <CCard>
            <CCardHeader>Fee Structure</CCardHeader>
            <CCardBody>
              <h1>Fee Structure</h1>
              <p>This is the fee structure page.</p>
            </CCardBody>
          </CCard>
        </CCol>
      </CRow>
    </CContainer>
  )
}

export default FeeStructure
