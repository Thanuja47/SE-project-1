import React from 'react'
const ManageSchools = () => {
  return (
    <div>
      <h1>Manage Schools</h1>
      <button>Add New School</button>
      <ul>
        <li>School of Law</li>
        <li>School of IT</li>
        <li>School of Business</li>
      </ul>
    </div>
  )
}

export default ManageSchools
