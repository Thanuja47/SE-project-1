import React, { useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import {
  CButton,
  CCard,
  CCardBody,
  CCardHeader,
  CCol,
  CContainer,
  CForm,
  CFormInput,
  CFormSelect,
  CRow,
  CAlert,
} from '@coreui/react'
import axios from 'axios'

const EditCourse = () => {
  const { id } = useParams()
  const [name, setName] = useState('')
  const [type, setType] = useState('')
  const [successMessage, setSuccessMessage] = useState('')
  const navigate = useNavigate()

  useEffect(() => {
    const fetchCourse = async () => {
      try {
        const token = localStorage.getItem('token')
        const response = await axios.get(`http://localhost:5000/api/courses/${id}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        })
        const course = response.data
        setName(course.name)
        setType(course.description)
      } catch (error) {
        console.error('Failed to fetch course:', error)
      }
    }

    fetchCourse()
  }, [id])

  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      const token = localStorage.getItem('token')
      const response = await axios.put(
        `http://localhost:5000/api/courses/${id}`,
        {
          name,
          description: type,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
      )
      console.log('Course updated:', response.data)
      setSuccessMessage('Course updated successfully!')
      setTimeout(() => {
        setSuccessMessage('')
        navigate('/courses/manage')
      }, 3000)
    } catch (error) {
      console.error('Failed to update course:', error)
    }
  }

  return (
    <CContainer>
      <CRow className="justify-content-center">
        <CCol md={8}>
          <CCard>
            <CCardHeader>Edit Course</CCardHeader>
            <CCardBody>
              <CForm onSubmit={handleSubmit}>
                <CRow className="mb-3">
                  <CCol>
                    <CFormInput
                      type="text"
                      placeholder="Course Name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      required
                    />
                  </CCol>
                </CRow>
                <CRow className="mb-3">
                  <CCol>
                    <CFormSelect value={type} onChange={(e) => setType(e.target.value)} required>
                      <option value="" disabled>
                        Course Type
                      </option>
                      <option value="Law Course">Law Course</option>
                      <option value="IT Course">IT Course</option>
                      <option value="Business Course">Business Course</option>
                    </CFormSelect>
                  </CCol>
                </CRow>
                <CRow>
                  <CCol className="text-right">
                    <CButton type="submit" color="primary">
                      Update Course
                    </CButton>
                  </CCol>
                </CRow>
              </CForm>
              {successMessage && (
                <CAlert color="success" className="mt-3">
                  {successMessage}
                </CAlert>
              )}
            </CCardBody>
          </CCard>
        </CCol>
      </CRow>
    </CContainer>
  )
}

export default EditCourse
