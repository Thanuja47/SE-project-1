import React from 'react'
import { CCard, CCardBody, CCardHeader, CCol, CContainer, CRow } from '@coreui/react'

const AttendanceManagement = () => {
  return (
    <CContainer>
      <CRow>
        <CCol>
          <CCard>
            <CCardHeader>Attendance Management</CCardHeader>
            <CCardBody>
              <h1>Attendance Management</h1>
              <p>This is the attendance management page.</p>
            </CCardBody>
          </CCard>
        </CCol>
      </CRow>
    </CContainer>
  )
}

export default AttendanceManagement
