import React from 'react'
import { CCard, CCardBody, CCardHeader, CCol, CContainer, CRow } from '@coreui/react'

const ClassScheduling = () => {
  return (
    <CContainer>
      <CRow>
        <CCol>
          <CCard>
            <CCardHeader>Class Scheduling</CCardHeader>
            <CCardBody>
              <h1>Class Scheduling</h1>
              <p>This is the class scheduling page.</p>
            </CCardBody>
          </CCard>
        </CCol>
      </CRow>
    </CContainer>
  )
}

export default ClassScheduling
