import React, { createContext, useState, useEffect } from 'react'
import PropTypes from 'prop-types'
import axios from 'axios'

export const AuthContext = createContext()

export const AuthProvider = ({ children }) => {
  AuthProvider.propTypes = {
    children: PropTypes.node.isRequired,
  }
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [userData, setUserData] = useState(null)

  useEffect(() => {
    const userSession = localStorage.getItem('userSession')
    if (userSession) {
      setIsAuthenticated(true)
      setUserData(JSON.parse(userSession))
    }
  }, [])

  const fetchUserData = async (token) => {
    try {
      const response = await axios.get('http://localhost:5000/api/auth/me', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      return response.data.user
    } catch (error) {
      console.error('Failed to fetch user data:', error)
      return null
    }
  }

  const login = (data) => {
    localStorage.setItem('userSession', JSON.stringify(data))
    setIsAuthenticated(true)
    setUserData(data)
  }

  const logout = () => {
    localStorage.removeItem('userSession')
    setIsAuthenticated(false)
    setUserData(null)
    window.localStorage.setItem('isLogged', false)
    console.log('User logged out')
    console.log('isLogged:', window.localStorage.getItem('isLogged'))
  }

  return (
    <AuthContext.Provider value={{ isAuthenticated, userData, login, logout, fetchUserData }}>
      {children}
    </AuthContext.Provider>
  )
}
