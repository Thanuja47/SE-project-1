export const logo = [
  '599 116',
  `<g>
    <g fill="none" fill-rule="nonzero">
      <g style="fill:#80d0ff;">
        <text x="50%" y="37%" dominant-baseline="middle" text-anchor="middle" font-size="80" fill="#80d0ff">SMS</text>
        <text x="50%" y="75%" dominant-baseline="middle" text-anchor="middle" font-size="40" fill="#80d0ff">School Management System</text>
      </g>
    </g>
  </g>`,
]
