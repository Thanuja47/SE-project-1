export const sygnet = [
  '102 115',
  `<g style="fill: currentColor">
    <text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" font-size="20" fill="currentColor">SMS</text>
    <text x="50%" y="70%" dominant-baseline="middle" text-anchor="middle" font-size="10" fill="currentColor">School Management System</text>
  </g>`,
]
